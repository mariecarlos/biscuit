$(document).ready(function() {


    $('#dob').keyup(function(){


        var nb_car = $(this).val().length;


        if(nb_car == 2 || nb_car == 5 || nb_car == 2) {


            $(this).val($(this).val()+'/');


        }


    });


});